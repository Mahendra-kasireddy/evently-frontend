export { QuotesHero } from './QuotesHero';
