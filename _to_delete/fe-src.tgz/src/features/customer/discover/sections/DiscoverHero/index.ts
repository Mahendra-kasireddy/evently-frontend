export { DiscoverHero } from './DiscoverHero';
